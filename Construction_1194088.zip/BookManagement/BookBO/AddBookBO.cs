﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
namespace BookBO
{
  public  class AddBookBO
    {
        string author, category, bookname;
        int price;
        int bookid;

        public string Author
        {
            get
            {
                return author;
            }

            set
            {
                author = value;
            }
        }

        public string Bookname
        {
            get
            {
                return bookname;
            }

            set
            {
                bookname = value;
            }
        }

        public string Category
        {
            get
            {
                return category;
            }

            set
            {
                category = value;
            }
        }

        public int Price
        {
            get
            {
                return price;
            }

            set
            {
                price = value;
            }
        }

        public int Bookid
        {
            get
            {
                return bookid;
            }

            set
            {
                bookid = value;
            }
        }

        public AddBookBO()
        {

        }
        public AddBookBO(string bookname,string author,string category,int price,int bookid)
        {
            this.Bookname = bookname;
            this.Author = author;
            this.Category = category;
            this.Price = price;
            this.Bookid = bookid;
        }
    }
}
