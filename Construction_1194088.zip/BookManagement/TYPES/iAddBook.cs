﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TYPES
{
   public interface iAddBook
    {
        string bookname { get; set; }
        string author { get; set; }
        int price { get; set; }
        string category { get; set; }
        int BookID { get; set; }

    }
}
