﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BookBO;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace BookDAL
{
   public class AddBookDAL
    {
        public int addBook(AddBookBO abo)
        {
           try
            {
                string str = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
                SqlConnection con = new SqlConnection();
                con.ConnectionString = str;

                SqlCommand cmd = new SqlCommand("usp_addBook", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.Parameters.Add(new SqlParameter("@BookName", abo.Bookname));
                cmd.Parameters.Add(new SqlParameter("@Author", abo.Author));
                cmd.Parameters.Add(new SqlParameter("@Price", abo.Price));
                cmd.Parameters.Add(new SqlParameter("@Category",abo.Category));


                SqlParameter obj = cmd.Parameters.Add("@BookID", SqlDbType.Int);
                obj.Direction = ParameterDirection.Output;
                int ret = cmd.ExecuteNonQuery();
                if (ret > 0)
                {
                    con.Close();
                    return (int)obj.Value ;
                }
                else
                {
                    con.Close();
                    return 0;
                }

            }
            catch(Exception)
            {
                
                throw;
            } 
            
        }
        public List<AddBookBO> viewBook(string drop)
        {
            List<AddBookBO> iab = new List<AddBookBO>();
            try
            {
                string str = ConfigurationManager.ConnectionStrings["connect"].ConnectionString;
                SqlConnection con = new SqlConnection();
                con.ConnectionString = str;
                
                SqlCommand cmd = new SqlCommand("usp_viewBook", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
               cmd.Parameters.Add(new SqlParameter("@Category",drop));
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    AddBookBO abo = new AddBookBO();
                    abo.Bookid = Convert.ToInt16(reader["@BookID"].ToString());
                    abo.Bookname = reader["@BookName"].ToString();
                    abo.Author = reader["@Author"].ToString();
                    abo.Category = reader["@Category"].ToString();
                    abo.Price = Convert.ToInt16(reader["@Price"].ToString());
                    iab.Add(abo);
                }
                return iab;
               
            }
            catch (Exception)
            {

                throw;
            }

           
        }
    }
}
