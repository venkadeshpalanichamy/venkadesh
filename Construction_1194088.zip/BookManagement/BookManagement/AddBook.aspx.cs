﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TYPES;
using BookBO;
using BookBLL;

namespace BookManagement
{
    public partial class AddBook : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["book"] != null)
            {
                lbl_category.Text = Session["book"].ToString();
            }
        }

        protected void btn_reset_Click(object sender, EventArgs e)
        {
            txt_author.Text = "";
            txt_bookname.Text = "";
            txt_price.Text = "";
        }

        protected void btn_submit_Click(object sender, EventArgs e)
        {
            try
            {
                AddBookBO abbo = new AddBookBO();
                abbo.Bookname = txt_bookname.Text;
                abbo.Author = txt_author.Text;
                abbo.Category = lbl_category.Text;
                abbo.Price = Convert.ToInt16(txt_price.Text);
                AddBookBLL abbll = new AddBookBLL();
                int ret = abbll.addBook(abbo);
                if (ret > 0)
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "success","alert('Record Inserted Successfully')",true);
                }
                else
                {
                    ClientScript.RegisterClientScriptBlock(this.GetType(), "Failure", "alert('Error in Adding Details');",true);
                }
            }
            catch(Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Failure",ex.Message);
            }
        }
    }
}