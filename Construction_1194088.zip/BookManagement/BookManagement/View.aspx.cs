﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TYPES;
using BookBO;
using BookBLL;

namespace BookManagement
{
    public partial class View : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_generate_Click(object sender, EventArgs e)
        {
            try
            {
                string drop = DropDownList1.SelectedItem.Value.ToString();
                
                AddBookBLL abll = new AddBookBLL();
                 grd_view.DataSource=  abll.viewBook(drop);
                grd_view.DataBind();
            }
            catch(Exception ex)
            {
                ClientScript.RegisterClientScriptBlock(this.GetType(), "error",ex.Message, true);
            }
          
        }
    }
}