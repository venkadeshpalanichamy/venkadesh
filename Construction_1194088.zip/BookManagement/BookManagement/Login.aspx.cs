﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace BookManagement
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_reset_Click(object sender, EventArgs e)
        {
            txt_username.Text = "";
            txt_password.Text = "";
            
        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                string username = txt_username.Text;
                string password = txt_password.Text;
                bool remember = chk_remember.Checked;
                if (FormsAuthentication.Authenticate(username,password))
                {
                    FormsAuthentication.RedirectFromLoginPage(username, remember);
                    lbl_time.Text = System.DateTime.Now.ToString();
                    Session["time"] = lbl_time.Text.ToString();
                }
                else
                {
                    lbl_check.Text = "Invalid Login Credentials!!";
                }
            }
        }
    }
}