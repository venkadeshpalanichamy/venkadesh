﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TYPES;
using BookDAL;
using BookBO;
namespace BookBLL
{
  public  class AddBookBLL
    {
        AddBookDAL abdal = new AddBookDAL();
        public int addBook(AddBookBO abo)
        {

            try
            {
              
                int ret = abdal.addBook(abo);
                return ret;
            }
            catch(Exception)
            {
                throw;
            }
        }
        public List<AddBookBO> viewBook(string drop)
        {
            try
            {
                List<AddBookBO> iab = new List<AddBookBO>();
                iab = abdal.viewBook(drop);
                return iab;

            }
            catch (Exception)
            {
                throw;
            }
            
           
        }
    }
}
