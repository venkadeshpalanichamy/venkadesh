***************Table creation*********************
create table tbl_BookDetails_1194088(
BookID int identity(1,1) primary key,
BookName varchar(20),
Author varchar(100),
Price int,
Category varchar(20))

sp_help tbl_BookDetails_1194088
*************************************************
create procedure usp_addBook(@BookID int out,@BookName varchar(20),
@Author varchar(100),@Price int,@Category varchar(20))
as
begin
 insert into tbl_BookDetails_1194088 values(@BookName,@Author,
 @Price,@Category)
 set @BookID=@@IDENTITY
end
go

exec usp_addBook 0,'Motivation','charles',459,'Fiction'
select * from tbl_BookDetails_1194088
************************************************************************
create procedure usp_viewBook(@Category varchar(20))
as
begin
 select * from tbl_BookDetails_1194088 where Category = @Category
 end
 go

 exec usp_viewBook 'Fiction'