﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class addBO
    {
        public int a { get; set; }
        public int b { get; set; }
        public int total { get; set; }
    }
}
