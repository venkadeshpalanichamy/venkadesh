﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using System.Data.Entity;
namespace DAL
{
    public class addDAL
    {
        public int adddal(addBO objaddBO)
        {
            addtable objadd = new addtable();

            //try
            //{
                objadd.a = objaddBO.a;
                objadd.b = objaddBO.b;
                objadd.total = objaddBO.total;
                using (var dbContext = new CHN12_MMS73_TESTEntities())
                {
                    dbContext.addtables.Add(objadd);
                    dbContext.SaveChanges();
                }
            //}
            //catch (Exception ex)
            //{

            //}
            return objadd.a;
        }
        //public List<addBO> Viewalldal()
        //{
        //    List<addtable> lstaddtable = new List<addtable>();
        //    List<addBO> lstaddBO = new List<addBO>();

        //    try
        //    {
        //        using (var dbContext = new CHN12_MMS73_TESTEntities())
        //        {
        //            lstaddtable = dbContext.addtables.ToList<addtable>();
        //        }

        //        foreach (addtable objaddtable in lstaddtable)
        //        {
        //            addBO objaddBO = new addBO();
        //            objaddtable.a = objaddBO.a;
        //            objaddtable.b = objaddBO.b;
        //            objaddtable.total = objaddBO.total;


        //            lstaddBO.Add(objaddBO);
        //        }
        //    }
        //    catch (Exception ex)
        //    {

        //    }

        //    return lstaddBO;
        //}
    }
}
