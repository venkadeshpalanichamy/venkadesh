﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using DAL;
namespace BLL
{
    public class addBLL
    {
        public int addbll(addBO objaddBO)
        {
            addDAL objaddDAL = new addDAL();

            return objaddDAL.adddal(objaddBO);
        }
        //public List<addBO> Viewallbll()
        //{
        //    addDAL objaddDAL = new addDAL();

        //    List<addBO> lstaddBO = objaddDAL.Viewalldal();

        //    return lstaddBO;
        //}
    }
}
 