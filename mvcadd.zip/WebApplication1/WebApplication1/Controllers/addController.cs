﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;
using BLL;
using BO;
namespace WebApplication1.Controllers
{
    public class addController : Controller
    {
        // GET: add
        public ActionResult Index()
        {
            return View();
        }

        // GET: add/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: add/Create
        public ActionResult Create()
        {

            addtable objaddModel = new addtable();
            //objEmployeeViewModel.CountryList = GetAllCountries();

            return View("create", objaddModel);
        }

        // POST: add/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            if (ModelState.IsValid)
            {
                addBO objaddBO = new addBO();
                objaddBO.a = int.Parse(Request.Form["a"]);
                objaddBO.b = int.Parse(Request.Form["b"]);
                objaddBO.total = int.Parse(Request.Form["total"]);

                addtable objaddModel = new addtable();


                addBLL objaddBLL = new addBLL();
                int a = objaddBLL.addbll(objaddBO);
                ViewBag.Message = String.Format("Success: Employee added. Employee Id is {0}", a);
            }
            return View("Create");
        }

        // GET: add/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: add/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: add/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: add/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
