﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using DataAccessLayer;

namespace CaseStudyInventoryManagementSystem
{
    public partial class AddProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                InventoryManagement objInventoryManagement = new InventoryManagement();
                ddlCategoryID.DataSource = objInventoryManagement.viewCategory();
                ddlCategoryID.DataTextField = "CategoryName";
                ddlCategoryID.DataValueField = "CategoryId";
                ddlCategoryID.DataBind();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            Product objProduct = new Product();
            objProduct.ProductName = txtProductName.Text;
            objProduct.ProductDescription = txtDescription.Text;
            objProduct.ProductPrice = Convert.ToInt32(txtPrice.Text);
            objProduct.CategoryID = int.Parse(ddlCategoryID.SelectedItem.Value);
            objProduct.IsActive = chkIsActive.Checked;

            InventoryManagement objInventoryManagement = new InventoryManagement();
            int returnValue = objInventoryManagement.addProduct(objProduct);
            if (returnValue == 1)
            {
                lblMessage.Text = "Product added Successfully";
            }
            else
                lblMessage.Text = "Product cannot be Added";
        }

        protected void ddlCategoryID_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}