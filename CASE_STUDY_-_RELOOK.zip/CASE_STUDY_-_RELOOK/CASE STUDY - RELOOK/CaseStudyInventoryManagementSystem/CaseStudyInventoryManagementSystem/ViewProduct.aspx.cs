﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using DataAccessLayer;

namespace CaseStudyInventoryManagementSystem
{
    public partial class ViewProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            BindData();

            //assign values to session variable
            Session["user"] = "Babu";
            
            //read from session
            string strFirstName = Session["user"].ToString();
        }

        private void BindData()
        {
            InventoryManagement objInventoryManagement = new InventoryManagement();
            grdViewProdut.DataSource = objInventoryManagement.viewProduct();
            grdViewProdut.DataBind();
        }

        protected void grdViewProdut_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            
        }

        protected void grdViewProdut_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void grdViewProdut_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int rowaffected = 0;

            string ProductName = ((TextBox)(grdViewProdut.Rows[e.RowIndex].FindControl("txtProductName"))).Text;

            grdViewProdut.EditIndex = -1;
            BindData();

        }

        protected void grdViewProdut_RowEditing(object sender, GridViewEditEventArgs e)
        {

        }
    }
}