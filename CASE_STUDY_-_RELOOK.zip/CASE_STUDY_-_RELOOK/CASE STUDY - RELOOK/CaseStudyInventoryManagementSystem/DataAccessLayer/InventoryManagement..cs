﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using BO;

namespace DataAccessLayer
{
    public class InventoryManagement
    {
        public int addProduct(Product objProduct)
        {
            //Get Connection String
            string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;
            
            //Define Sql Connection
            SqlConnection objSqlConnection = new SqlConnection(connString);
            
            //Define Sql Command 
            SqlCommand objSqlCommand = new SqlCommand();
            objSqlCommand.Connection = objSqlConnection;
            objSqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
            objSqlCommand.CommandText = "usp_AddProduct_345994";
            
            //Define Sql Parameters
            objSqlCommand.Parameters.AddWithValue("@Name", objProduct.ProductName);
            objSqlCommand.Parameters.AddWithValue("@Description",objProduct.ProductDescription);
            objSqlCommand.Parameters.AddWithValue("@Price",objProduct.ProductPrice);
            objSqlCommand.Parameters.AddWithValue("@Categoryid", objProduct.CategoryID);
            objSqlCommand.Parameters.AddWithValue("@IsActive", objProduct.IsActive);
            
            //Open Sql Connection           
            objSqlConnection.Open();

            //Execute the command
            int result = objSqlCommand.ExecuteNonQuery();

            //Close Sql Connection
            objSqlConnection.Close();

            return result;
        }

        public DataSet viewCategory()
        {
            //Get Connection String
            string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

            //Define Sql Connection
            SqlConnection objSqlConnection = new SqlConnection(connString);

            //Define Sql Command 
            SqlCommand objSqlCommand = new SqlCommand();
            objSqlCommand.Connection = objSqlConnection;
            objSqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
            objSqlCommand.CommandText = "usp_ViewCategory_345994";

            //define sqldataAdapter
            SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter();
            objSqlDataAdapter.SelectCommand = objSqlCommand;

            //Define dataset
            DataSet objDataSet = new DataSet();
            objSqlDataAdapter.Fill(objDataSet);
            return objDataSet;

            //Open Sql Connection           
            //objSqlConnection.Open();

            //Execute the command
            //int result = objSqlCommand.ExecuteNonQuery();

            //Close Sql Connection
            //objSqlConnection.Close();
            //return new DataSet();

        }

        public DataSet viewProduct()
        {   
            //Get Connection String
            string connString = ConfigurationManager.ConnectionStrings["DbConnection"].ConnectionString;

            //Define Sql Connection
            SqlConnection objSqlConnection = new SqlConnection(connString);

            //Define Sql Command 
            SqlCommand objSqlCommand = new SqlCommand();
            objSqlCommand.Connection = objSqlConnection;
            objSqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
            objSqlCommand.CommandText = "usp_ViewProduct_345994";

            //define sqldataAdapter
            SqlDataAdapter objSqlDataAdapter = new SqlDataAdapter();
            objSqlDataAdapter.SelectCommand = objSqlCommand;

            //Define dataset
            DataSet objDataSet = new DataSet();
            objSqlDataAdapter.Fill(objDataSet);
            return objDataSet;

             //Open Sql Connection           
            //objSqlConnection.Open();

            //Execute the command
            //int result = objSqlCommand.ExecuteNonQuery();

            //Close Sql Connection
            //objSqlConnection.Close();
            //return new DataSet();
            
        }
    }
}