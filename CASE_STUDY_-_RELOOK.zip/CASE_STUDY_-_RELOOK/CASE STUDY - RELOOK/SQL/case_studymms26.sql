create table tblCategory_345994(
CategoryId int identity(1001,1),
CategoryName varchar(20) unique not null,
IsActive bit check(Isactive=0 or IsActive=1)) 
go

alter table tblCategory_345994
add constraint cnstPrimaryKey  primary key(CategoryId) 
go

create table tblProduct_345994
(productID int identity(10001,1) primary key,
 productName varchar(20) unique not null,
 productDescription varchar(200),
 productPrice int check(productPrice between 25000 and 250000),
 categoryID int foreign key references tblCategory_345994(CategoryID),
 isActive bit default 1)
 go 

 insert into tblCategory_345994 values('MotorCycle',1); 
 insert into tblCategory_345994 values('Scooter',1);
 insert into tblCategory_345994 values('Superbikes',1);
 go

 select * from tblCategory_345994;
 go

 create procedure usp_ViewProduct_345994
 as
 begin
 select * from tblProduct_345994
 end
 go

 create procedure usp_AddProduct_345994
 (
 @Name varchar(20),
 @Description varchar(200),
 @Price int,
 @Categoryid int,
 @IsActive bit
 )
 as
 begin
	insert into tblProduct_345994
	values(@Name,@Description,@Price,@Categoryid,@IsActive)
 end
 go

 alter procedure usp_ViewCategory_345994
 as
 begin
 select CategoryId,CategoryName from tblCategory_345994
 end
 go

 delete from tblCategory_345994 
 where CategoryId=1004