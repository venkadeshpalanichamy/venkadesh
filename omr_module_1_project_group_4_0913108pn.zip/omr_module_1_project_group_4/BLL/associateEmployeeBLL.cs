﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using BO;
using System.Data;


namespace BLL
{
   public  class associateEmployeeBLL
    {
        associateEmployeeDAL objdal = new associateEmployeeDAL();
        public DataTable view(associateEmployeeBO objbo)
        {
            return objdal.viewdal(objbo);

        }
        public DataTable viewall()
        {
            return objdal.viewall();
        }
        public DataTable viewbyass(int associateid)
        {
            return objdal.viewbyass(associateid);
        }
        public void edit(associateEmployeeBO objbo)
        {
            objdal.edit(objbo);
        }
        public int getdata(associateEmployeeBO objbo)
        {

            return objdal.getdata(objbo);
        }
    }
}
