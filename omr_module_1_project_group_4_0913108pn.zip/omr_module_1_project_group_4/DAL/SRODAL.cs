﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class SRODAL
    {

        public int EditSRO(SROBO objbo)
        {
            try { 
            SqlConnection conn = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;Integrated Security=False;User ID=mms73group4;Password=mms73group4;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            int ret = 0;
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd = new SqlCommand("usp_editSRO", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@sroid",objbo.SROID));
            cmd.Parameters.Add(new SqlParameter("@addressline1",objbo.Address_1));
            cmd.Parameters.Add(new SqlParameter("@addressline2",objbo.Address_2));
            cmd.Parameters.Add(new SqlParameter("@area",objbo.AreaLocation));
            cmd.Parameters.Add(new SqlParameter("@district",objbo.District));
            cmd.Parameters.Add(new SqlParameter("@state",objbo.State));
            cmd.Parameters.Add(new SqlParameter("@pincode",objbo.Pincode));
            cmd.Parameters.Add(new SqlParameter("@officecontact",objbo.OfficeContact));
            cmd.Parameters.Add(new SqlParameter("@sroanno",objbo.BankAccount));
            cmd.Parameters.Add(new SqlParameter("@bankname",objbo.BankName));
            cmd.Parameters.Add(new SqlParameter("@branch",objbo.Branch));
            cmd.Parameters.Add(new SqlParameter("@ifsc",objbo.IFSCCode));

            ret = cmd.ExecuteNonQuery();
            
            return ret;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        public int sroidv;
        static SqlConnection cn;
        static SqlCommand cmd;
        public int create(SROBO bo)
        {
            try {  
                    
           string conStr = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4";
            cn = new SqlConnection(conStr);
            cn.Open();
            cmd = new SqlCommand("CreateSRO", cn); cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@address1", bo.Address_1);
            cmd.Parameters.AddWithValue("@address2", bo.Address_2);
            cmd.Parameters.AddWithValue("@area", bo.AreaLocation);
            cmd.Parameters.AddWithValue("@district", bo.District);
            cmd.Parameters.AddWithValue("@state", bo.State);
            cmd.Parameters.AddWithValue("@country", bo.Country);
            cmd.Parameters.AddWithValue("@bankname", bo.BankName);
            cmd.Parameters.AddWithValue("@bankaccount", bo.BankAccount);
            cmd.Parameters.AddWithValue("@branch", bo.Branch);
            cmd.Parameters.AddWithValue("@ifsccode", bo.IFSCCode);
            cmd.Parameters.AddWithValue("@createdby", bo.Createdby);
            cmd.Parameters.AddWithValue("@createddate", bo.CreatedDate);
            //cmd.Parameters.AddWithValue("@modifiedby", bo.Modifiedby);
            //cmd.Parameters.AddWithValue("@modifieddate", bo.ModifiedDate);
            cmd.Parameters.AddWithValue("@status", bo.Status);
            SqlParameter SROid = cmd.Parameters.Add("@sroid", SqlDbType.Int);
            SROid.Direction = ParameterDirection.Output;
            int i = cmd.ExecuteNonQuery();
            sroidv = (int)cmd.Parameters["@sroid"].Value;
            if (i > 0)
            {
                return sroidv;
            }
            else
                return 0;
            }
            catch (Exception ex)
            {
                return 0;

            }
        }




    }
}
