﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DAL
{
    public class associateEmployeeDAL
    {
        static SqlConnection cn;
        static SqlCommand cmd;
        int assid = 0;
        public DataTable viewdal(associateEmployeeBO objbo)
        {
            try
            {
                SqlConnection cn = new SqlConnection("Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4");
                //cn = new SqlConnection(conStr);
                cn.Open();
                int srid = objbo.sroid;
                string str = "SELECT Createdby,Createddate,Modifiedby,Modifieddate from addsrooffice where SROID=" + srid;
                SqlDataAdapter da = new SqlDataAdapter(str, cn);
                DataSet ds = new DataSet();
                da.Fill(ds, "addsrooffice");
                return ds.Tables["addsrooffice"];
            }catch(Exception ex)
            {
                return null;
            }

        }
        public DataTable viewall()
        {
            try { 
            SqlConnection cn = new SqlConnection("Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4");
            //cn = new SqlConnection(conStr);
            cn.Open();
            SqlCommand cmd = new SqlCommand();


            SqlDataAdapter da = new SqlDataAdapter("viewall", cn);
            DataSet ds = new DataSet();
            da.Fill(ds, "Employee_Association");

            return ds.Tables["Employee_Association"];
            }
            catch (Exception ex)
            {
                return null;

            }
        }
        public DataTable viewbyass(int associateid)
        {
            try
            {
                SqlConnection cn = new SqlConnection("Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4");
                //cn = new SqlConnection(conStr);

                SqlCommand cmd = new SqlCommand("viewbypass", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Connection = cn;
                cmd.Parameters.AddWithValue("@associateid", associateid);
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "viewbypass");
                SqlCommandBuilder cb = new SqlCommandBuilder(da);

                da.Update(ds, "viewbypass");



                return ds.Tables["viewbypass"];
            
              }catch(Exception ex)
            {
                return null;
            }
}
        public void edit(associateEmployeeBO objbo)
        {
            try
            {
                SqlConnection cn = new SqlConnection("Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4");
                //cn = new SqlConnection(conStr);
                //cn.Open();
                SqlCommand cmd = new SqlCommand("edit", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Connection = cn;

                SqlDataAdapter da = new SqlDataAdapter();
                cmd.Parameters.AddWithValue("@associateid", objbo.associateid);
                cmd.Parameters.AddWithValue("@sroid", objbo.sroid);
                cmd.Parameters.AddWithValue("@modifiedby", objbo.modifiedby);
                cmd.Parameters.AddWithValue("@modifieddate", objbo.modifieddate);
                //int a = cmd.ExecuteNonQuery();
                //cn.Close();
                da.SelectCommand = cmd;
                DataSet ds = new DataSet();
                da.Fill(ds, "edit");
            
              }catch(Exception ex)
            {

            }

}

        public int getdata(associateEmployeeBO objbo)
        {
            try
            {
                string conStr = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4";
                cn = new SqlConnection(conStr);
                cn.Open();
                cmd = new SqlCommand("view", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                objbo.createdby = "admin";
                objbo.createddate = DateTime.Now;
                cmd.Parameters.AddWithValue("@employeeid", objbo.employeeid);
                cmd.Parameters.AddWithValue("@sroid", objbo.sroid);
                cmd.Parameters.AddWithValue("@Description", objbo.Description);
                cmd.Parameters.AddWithValue("@createdby", objbo.createdby);
                cmd.Parameters.AddWithValue("@createddate", objbo.createddate);
                SqlParameter SROid = cmd.Parameters.Add("@associateid", SqlDbType.Int);
                SROid.Direction = ParameterDirection.Output;
                int i = cmd.ExecuteNonQuery();
                assid = (int)cmd.Parameters["@associateid"].Value;
                if (i > 0)
                {
                    return assid;
                }
                else
                    return 0;
            }
            catch (Exception)
            {
                return 0;
            }
        }
    }
}
