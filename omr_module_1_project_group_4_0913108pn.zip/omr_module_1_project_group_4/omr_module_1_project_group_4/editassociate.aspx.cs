﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using BO;

namespace omr_module_1_project_group_4
{
    public partial class editassociate : System.Web.UI.Page
    {
        DateTime now;
        String who;
        associateEmployeeBO objbo = new associateEmployeeBO();
        associateEmployeeBLL objbll = new associateEmployeeBLL();
        //bo objbo = new bo();
        //bll objbll = new bll();
        protected void Page_Load(object sender, EventArgs e)
        {
            now = DateTime.Now;
           who = Session["user"].ToString();
        }

        public void Btn_edit_Click(object sender, EventArgs e)
        {
            int associateid = int.Parse(Dropdownlist1.SelectedItem.Value);
            GridView1.DataSource = objbll.viewbyass(associateid);
            GridView1.DataBind();

        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
            objbo.associateid = int.Parse(Dropdownlist1.SelectedItem.Value);
            objbo.sroid = int.Parse(txtsroid.Value);
            objbo.modifieddate = now;

            objbo.modifiedby = who;
            objbll.edit(objbo);

            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + objbo.associateid + "'assid edited);", true);


        }
    }
}