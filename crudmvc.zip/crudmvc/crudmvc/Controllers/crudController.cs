﻿using BLL;
using BO;
using crudmvc.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace crudmvc.Controllers
{
    public class crudController : Controller
    {
        // GET: crud
        public ActionResult Index()
        {
            return View();
        }

        // GET: crud/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: crud/Create
        public ActionResult Create()
        {
            UserTable_module2 objusrmodel = new UserTable_module2();

            return View("Create", objusrmodel);
        }

        // POST: crud/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            if (ModelState.IsValid)
            {
                usrBO objaddBO = new usrBO();
                objaddBO.UserId = int.Parse(Request.Form["UserId"]);
                objaddBO.Password = Request.Form["Password"];
                objaddBO.Title = Request.Form["Title"];
                objaddBO.FirstName = Request.Form["FirstName"];
                objaddBO.LastName = Request.Form["LastName"];
                objaddBO.DateOfBirth = DateTime.Parse(Request.Form["DateOfBirth"]);
                objaddBO.Gender = bool.Parse(Request.Form["Gender"]);
                objaddBO.StreetAddress = Request.Form["StreetAddress"];

                objaddBO.Nationality = Request.Form["Nationality"];
                objaddBO.TownOrCity = Request.Form["TownOrCity"];
                objaddBO.State = Request.Form["State"];
                objaddBO.ZipCode = int.Parse(Request.Form["ZipCode"]);

                objaddBO.MobileNumber = int.Parse(Request.Form["MobileNumber"]);
                objaddBO.AlternatePhone = int.Parse(Request.Form["AlternatePhone"]);
                objaddBO.PhoneNumber = int.Parse(Request.Form["PhoneNumber"]);
                objaddBO.EmailAddress = Request.Form["EmailAddress"];
                objaddBO.CompanyName = Request.Form["CompanyName"];
                objaddBO.OfficeAddress = Request.Form["OfficeAddress"];
                objaddBO.CreatedBy = Request.Form["CreatedBy"];
                objaddBO.CreatedDate = DateTime.Parse(Request.Form["CreatedDate"]);
                objaddBO.ModifiedBy = Request.Form["ModifiedBy"];
                objaddBO.ModifiedDate = DateTime.Parse(Request.Form["ModifiedDate"]);




                UserTable_module2 objaddModel = new UserTable_module2();


                usrBLL objaddBLL = new usrBLL();
                int a = objaddBLL.usrbll(objaddBO);
                ViewBag.Message = String.Format("Success: user added. user Id is {0}", a);
            }
            return View("Create");
        }

        // GET: crud/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: crud/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: crud/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: crud/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
        public ActionResult viewall()
        {
            usrBLL objusrBLL = new usrBLL();
            List<usrBO> lstEmployeeBO = objusrBLL.ViewAllEmployees();
            lstEmployeeBO.Reverse();

            List<UserTable_module2> lstEmployeeViewModel = new List<UserTable_module2>();
            foreach (usrBO objEmployeeBO in lstEmployeeBO)
            {
                UserTable_module2 objEmployeeViewModel = new UserTable_module2();
                objEmployeeViewModel.UserId = objEmployeeBO.UserId;
                objEmployeeViewModel.Password = objEmployeeBO.Password;
                objEmployeeViewModel.Title = objEmployeeBO.Title;
                objEmployeeViewModel.FirstName = objEmployeeBO.FirstName;
                objEmployeeViewModel.LastName = objEmployeeBO.LastName;
                objEmployeeViewModel.DateOfBirth= objEmployeeBO.DateOfBirth;
                objEmployeeViewModel.Gender = objEmployeeBO.Gender;
                objEmployeeViewModel.StreetAddress = objEmployeeBO.StreetAddress;
                objEmployeeViewModel.Nationality = objEmployeeBO.Nationality;
                objEmployeeViewModel.TownOrCity = objEmployeeBO.TownOrCity;
                objEmployeeViewModel.State = objEmployeeBO.State;
                objEmployeeViewModel.ZipCode = objEmployeeBO.ZipCode;
                objEmployeeViewModel.MobileNumber = objEmployeeBO.MobileNumber;
                objEmployeeViewModel.AlternatePhone = objEmployeeBO.AlternatePhone;
                objEmployeeViewModel.PhoneNumber = objEmployeeBO.PhoneNumber;
                objEmployeeViewModel.EmailAddress = objEmployeeBO.EmailAddress;
                objEmployeeViewModel.CompanyName = objEmployeeBO.CompanyName;
                objEmployeeViewModel.OfficeAddress = objEmployeeBO.OfficeAddress;
                objEmployeeViewModel.CreatedBy = objEmployeeBO.CreatedBy;
                objEmployeeViewModel.CreatedDate = objEmployeeBO.CreatedDate;
                objEmployeeViewModel.ModifiedBy = objEmployeeBO.ModifiedBy;
                objEmployeeViewModel.ModifiedDate = objEmployeeBO.ModifiedDate;

                lstEmployeeViewModel.Add(objEmployeeViewModel);
            }
            return View("viewall", lstEmployeeViewModel);
        }
    }
}
