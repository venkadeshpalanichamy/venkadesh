﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using DAL;
namespace BLL
{
    public class usrBLL
    {
        public int usrbll(usrBO objusrBO)
        {
            usrDAL objusrDAL = new usrDAL();

            return objusrDAL.usrdal(objusrBO);
        }
        public List<usrBO> ViewAllEmployees()
        {
            usrDAL objEmployeeDAL = new usrDAL();

            List<usrBO> lstEmployeeBO = objEmployeeDAL.ViewAllEmployees();

            return lstEmployeeBO;
        }
    }
}
