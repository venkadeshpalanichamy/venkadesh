﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
namespace DAL
{
    public class usrDAL
    {
        public int usrdal(usrBO objusrBO)
        {
            UserTable_module2 objusrtbl = new UserTable_module2();


            objusrtbl.UserId = objusrBO.UserId;
            objusrtbl.Password = objusrBO.Password;
            objusrtbl.Title = objusrBO.Title;
            objusrtbl.FirstName = objusrBO.FirstName;
            objusrtbl.LastName = objusrBO.LastName;
            objusrtbl.DateOfBirth = objusrBO.DateOfBirth;
            objusrtbl.Gender = objusrBO.Gender;
            objusrtbl.StreetAddress = objusrBO.StreetAddress;
            objusrtbl.Nationality = objusrBO.Nationality;
            objusrtbl.State = objusrBO.State;
            objusrtbl.TownOrCity = objusrBO.TownOrCity;
            objusrtbl.ZipCode = objusrBO.ZipCode;
            objusrtbl.MobileNumber = objusrBO.MobileNumber;
            objusrtbl.AlternatePhone = objusrBO.AlternatePhone;
            objusrtbl.PhoneNumber = objusrBO.PhoneNumber;
            objusrtbl.EmailAddress = objusrBO.EmailAddress;
            objusrtbl.CompanyName = objusrBO.CompanyName;
            objusrtbl.OfficeAddress = objusrBO.OfficeAddress;
            objusrtbl.CreatedBy = objusrBO.CreatedBy;
            objusrtbl.CreatedDate = objusrBO.CreatedDate;
            objusrtbl.ModifiedBy = objusrBO.ModifiedBy;
            objusrtbl.ModifiedDate = objusrBO.ModifiedDate;


            using (var dbContext = new CHN12_MMS73_Group4Entities())
            {
                dbContext.UserTable_module2.Add(objusrtbl);
                dbContext.SaveChanges();
            }

            return objusrtbl.UserId;
        }
        public List<usrBO> ViewAllEmployees()
        {
            List<UserTable_module2> lstEmployee_345994 = new List<UserTable_module2>();
            List<usrBO> lstEmployeeBO = new List<usrBO>();

            try
            {
                using (var dbContext = new CHN12_MMS73_Group4Entities())
                {
                    lstEmployee_345994 = dbContext.UserTable_module2.ToList<UserTable_module2>();
                }

                foreach (UserTable_module2 objEmployee_345994 in lstEmployee_345994)
                {
                    usrBO objEmployeeBO = new usrBO();
                    objEmployeeBO.UserId= objEmployee_345994.UserId;
                    objEmployeeBO.Password = objEmployee_345994.Password;
                    objEmployeeBO.Title = objEmployee_345994.Title;
                    objEmployeeBO.FirstName = objEmployee_345994.FirstName;
                    objEmployeeBO.LastName = objEmployee_345994.LastName;
                    objEmployeeBO.DateOfBirth = DateTime.Parse(objEmployee_345994.DateOfBirth.ToString());
                    objEmployeeBO.Gender = bool.Parse(objEmployee_345994.Gender.ToString());
                    objEmployeeBO.StreetAddress = objEmployee_345994.StreetAddress.ToString();
                    objEmployeeBO.Nationality = objEmployee_345994.Nationality.ToString();
                    objEmployeeBO.State = objEmployee_345994.State.ToString();
                    objEmployeeBO.TownOrCity = objEmployee_345994.TownOrCity;
                    objEmployeeBO.ZipCode = int.Parse(objEmployee_345994.ZipCode.ToString());
                    objEmployeeBO.MobileNumber = int.Parse(objEmployee_345994.MobileNumber.ToString()) ;
                    objEmployeeBO.AlternatePhone = int.Parse(objEmployee_345994.AlternatePhone.ToString()) ;
                    objEmployeeBO.PhoneNumber = int.Parse(objEmployee_345994.PhoneNumber.ToString());
                    objEmployeeBO.EmailAddress = objEmployee_345994.EmailAddress;
                    objEmployeeBO.CompanyName = objEmployee_345994.CompanyName;
                    objEmployeeBO.OfficeAddress = objEmployee_345994.OfficeAddress;
                    objEmployeeBO.CreatedBy = objEmployee_345994.CreatedBy;
                    objEmployeeBO.CreatedDate = DateTime.Parse(objEmployee_345994.CreatedDate.ToString());
                    objEmployeeBO.ModifiedBy = objEmployee_345994.ModifiedBy;
                    objEmployeeBO.ModifiedDate = DateTime.Parse(objEmployee_345994.ModifiedDate.ToString());
                    

                    lstEmployeeBO.Add(objEmployeeBO);
                }
            }
            catch (Exception ex)
            {

            }

            return lstEmployeeBO;
        }
    }
}
