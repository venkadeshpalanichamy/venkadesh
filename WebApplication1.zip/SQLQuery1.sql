create table tbl_Bookdetails1196180(BookID int Identity(1,1) primary key,
BookName   varchar(20),
Author  Varchar (100),
Price  int,
Category  Varchar(20))
create procedure sp_adddetails1196180(@bookname varchar(20),@author varchar(20),@price int,@category varchar(20))
as
begin
insert into tbl_Bookdetails1196180(bookname,author,price,category)
values(@bookname,@author,@price,@category)
end
create procedure sp_viewdetails1196180 
as
begin
select * from tbl_Bookdetails1196180 where category=@category
end
