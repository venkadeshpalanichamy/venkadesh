﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bo;
using Dal;
using System.Data;

namespace Bll
{
    public class bookbll
    {
        bookdal objdal = new bookdal();
        public int addbook(bookbo objbo)
        {
            
            return objdal.addbook(objbo);

        }
        public DataSet viewbook(bookbo objbo)
        {
            return objdal.viewbook(objbo);
        }
    }
}
