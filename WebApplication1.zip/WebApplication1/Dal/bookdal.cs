﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using Bo;

namespace Dal
{
    public class bookdal

    {
        public int addbook(bookbo obj1bo)
        {
            string str= "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;User Id=mms73user;Password=mms73user";
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_adddetails1196180";
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@bookname", obj1bo.Bookname);
            cmd.Parameters.AddWithValue("@author", obj1bo.author);
            cmd.Parameters.AddWithValue("@price", obj1bo.price);
            cmd.Parameters.AddWithValue("@category", obj1bo.Category);
            int r = cmd.ExecuteNonQuery();
            con.Close();
            return r;
        }
        public DataSet viewbook(bookbo obj1bo)
        {
            string str = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;User Id=mms73user;Password=mms73user";
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_view1details1196180";
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@category", obj1bo.category);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            return ds;
        }

    }
}
