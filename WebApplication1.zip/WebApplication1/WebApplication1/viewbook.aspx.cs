﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bll;
using Bo;

namespace WebApplication1
{
    public partial class viewbook : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string name = Session["userid"].ToString();
            Label2.Text = name;
        }

        protected void Btn1_view_Click(object sender, EventArgs e)
        {
            bookbll objbll = new bookbll();
            string category = txtcategory.Text;
            bookbo objbo = new bookbo();
          
            GridView1.DataSource = objbll.viewbook(objbo);
            GridView1.DataBind();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}