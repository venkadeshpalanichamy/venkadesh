﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace WebApplication1
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Btn1_login_Click(object sender, EventArgs e)
        {
            string name = txtusername.Text;
            string password = txtpassword.Text;
            if(FormsAuthentication.Authenticate(name,password))
            {
                FormsAuthentication.RedirectFromLoginPage(name, false);
                Session["userid"] = txtusername.Text;
                Response.Redirect("homepage.aspx");
            }
            else
            {
                Label1.Text = "invalid Login";
            }
        }
    }
}