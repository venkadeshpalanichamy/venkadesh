﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Bll;
using Bo;

namespace WebApplication1
{
    public partial class adddetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string name = Session["userid"].ToString();
            Label1.Text = name;
            txtcategory.Text = Session["Category"].ToString();
            txtcategory.Enabled = false;
            
        }

        protected void btn1_submit_Click(object sender, EventArgs e)
        {
            bookbll objbll = new bookbll();
            string bookname = txtbookname.Text;
            string author =txtauthor.Text;
            int price = int.Parse(txtprice.Text);
            string category = txtcategory.Text;
            bookbo obj1bo = new bookbo();
            obj1bo.bookname = bookname;
            obj1bo.author = author;
            obj1bo.price = price;
            obj1bo.category = category;
            int res= objbll.addbook(obj1bo);
            
            if(res>0)
            {
                label3.Text="inserted successfully";
            }
            else
            {
                label3.Text="not inserted";
            }
            
        }
    }
}