﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class homepage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string name = Session["userid"].ToString();
            Label1.Text = name;
        }

        protected void Btn1_add_Click(object sender, EventArgs e)
        {
            Response.Redirect("category.aspx");
        }

        protected void btn2_view_Click(object sender, EventArgs e)
        {
            Response.Redirect("viewbook.aspx");
        }
    }
}