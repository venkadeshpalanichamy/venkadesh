﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication7.Models;
using BO;
using BLL;

namespace WebApplication7.Controllers
{
    public class crudController : Controller
    {
        // GET: crud
        public ActionResult Index()
        {
            return View();
        }

        // GET: crud/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: crud/Create
        public ActionResult Create()
        {
            UserTable_module2 objusrmodel = new UserTable_module2();

            return View("Create",objusrmodel);
        }

        // POST: crud/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    usrBO objaddBO = new usrBO();
                    objaddBO.UserId = int.Parse(Request.Form["UserId"]);
                    objaddBO.Password =Request.Form["Password"];
                    objaddBO.Title = Request.Form["Title"];
                    objaddBO.FirstName = Request.Form["FirstName"];
                    objaddBO.LastName = Request.Form["LastName"];
                    objaddBO.DateOfBirth = DateTime.Parse(Request.Form["DateOfBirth"]);
                    objaddBO.Gender = bool.Parse(Request.Form["Gender"]);
                    objaddBO.Nationality = Request.Form["Nationality"];
                    objaddBO.TownOrCity = Request.Form["TownOrCity"];
                    objaddBO.State = Request.Form["State"];
                    objaddBO.ZipCode = int.Parse(Request.Form["ZipCode"]);

                    objaddBO.MobileNumber = int.Parse(Request.Form["MobileNumber"]);
                    objaddBO.AlternatePhone = int.Parse(Request.Form["AlternatePhone"]);
                    objaddBO.PhoneNumber = int.Parse(Request.Form["PhoneNumber"]);
                    objaddBO.EmailAddress = Request.Form["EmailAddress"];
                    objaddBO.CompanyName = Request.Form["CompanyName"];
                    objaddBO.OfficeAddress = Request.Form["OfficeAddress"];
                    objaddBO.CreatedBy = Request.Form["CreatedBy"];
                    objaddBO.CreatedDate = DateTime.Parse(Request.Form["CreatedDate"]);
                    objaddBO.ModifiedBy = Request.Form["ModifiedBy"];
                    objaddBO.ModifiedDate = DateTime.Parse(Request.Form["ModifiedDate"]);


                    

                    UserTable_module2 objaddModel = new UserTable_module2();


                    usrBLL objaddBLL = new usrBLL();
                    int a = objaddBLL.addbll(objaddBO);
                    ViewBag.Message = String.Format("Success: Employee added. Employee Id is {0}", a);
                }
                return View("Create");
            }
            catch
            {
                return View();
            }
        }

        // GET: crud/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: crud/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: crud/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: crud/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
