﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using DAL;
namespace BLL
{
    public class addBLL
    {
        public int addbll(addBO objbo)
        {
            addDAL objEmployeeDAL = new addDAL();

            return objEmployeeDAL.adddal(objbo);
        }
    }
}
