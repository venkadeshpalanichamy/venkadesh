﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;
using BO;
using BLL;

namespace WebApplication2.Controllers
{
    public class homeController : Controller
    {
        // GET: home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult create()
        {
            Model1 objEmployeeViewModel = new Model1();
            //objEmployeeViewModel.CountryList = GetAllCountries();

            return View("create", objEmployeeViewModel);
            
        }
        [HttpPost]
        public ActionResult AddEmployee(string Create)
        {
            System.Diagnostics.Trace.TraceInformation("Hello..");

           

            if (ModelState.IsValid)
            {
                addBO objEmployeeBO = new addBO();
                objEmployeeBO.a = int.Parse(Request.Form["a"]);
                objEmployeeBO.b = int.Parse(Request.Form["b"]);

                Model1 objEmployeeViewModel = new Model1();


                addBLL objEmployeeBLL = new addBLL();
                int a = objEmployeeBLL.addbll(objEmployeeBO);
                ViewBag.Message = String.Format("Success: Employee added. Employee Id is {0}", a);
            }    return View("create");
        }
    }
}