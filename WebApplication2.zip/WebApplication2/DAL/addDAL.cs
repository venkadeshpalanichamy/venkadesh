﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using System.Data.Entity;

namespace DAL
{
    public class addDAL
    {
        public int adddal(addBO objbo)
        {
            addtable objadd = new addtable();

            try
            {
                objadd.a =objbo.a;
                objadd.b=objbo.b;                

                using (var dbContext = new CHN12_MMS73_TESTEntities1())
                {
                    dbContext.addtables.Add(objadd);
                    dbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            {

            }
            return objadd.a;
        }
    }
}
