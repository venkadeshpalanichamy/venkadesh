﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;
namespace omr_module_1_project_group_4
{
    public partial class add_employee : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }             
        protected void submit_Click(object sender, EventArgs e)
        {
            EmployeeBO objemp = new EmployeeBO();
            objemp.FirstName = txtfname.Value.ToString();
            objemp.LastName = txtlname.Value.ToString();
            objemp.Address = txtadd.Value.ToString();
            objemp.Contactno =  long.Parse(txtcno.Value.ToString());
            objemp.Ctc = float.Parse(txtctc.Value.ToString());
            objemp.Dob =  DateTime.Parse(txtdob.Value.ToString());
            objemp.Gender = Request.Form["gender"].ToString();
            objemp.Email = txtemail.Value.ToString(); 
            objemp.Yoe= int.Parse(txtyoe.Value.ToString()); 
            objemp.Doj = DateTime.Parse(txtdoj.Value.ToString()); 
            objemp.Password= txtpwd.Value.ToString();
            objemp.Role = Request.Form["role"].ToString();
            objemp.Place = txtplace.Value.ToString(); 
            objemp.Status=txtstatus.Value.ToString(); 

            EmployeeBLL objbllemp = new EmployeeBLL();
            int intresult = objbllemp.AddEmployee(objemp);
            
            if (intresult > 1)
            {
                // lblmsg.Text = "Details added sucessfully";
                // LoadGrid();
                Response.Write("<script>alert('DONE ID IS "+intresult+"')</script>");
            }
            else if (intresult == -2)
            {
                Response.Write("<script>alert('NOT DONE')</script>");

                //lblmsg.Text = "Same ID exists";
            }
            else
                Response.Write("<script>alert('NOT asd DONE')</script>");

        }
    }
}