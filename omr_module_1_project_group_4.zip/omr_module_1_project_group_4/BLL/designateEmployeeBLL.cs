﻿
using BO;
using DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLL
{
   public  class designateEmployeeBLL
    {
        public int addSRAssistant(designateEmployeeBO obj)
        {
            designateEmployeeDAL objclss = new designateEmployeeDAL();

            return objclss.addSRAssistant(obj);

        }
        public int EditSRAssistant(designateEmployeeBO obj)
        {
            designateEmployeeDAL objclass = new designateEmployeeDAL();
            return objclass.EditSRAssistant(obj);
        }
    }
}
