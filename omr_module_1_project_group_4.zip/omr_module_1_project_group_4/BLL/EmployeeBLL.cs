﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using DAL;
namespace BLL
{
    public class EmployeeBLL
    {
        public int AddEmployee(EmployeeBO objbo)
        {
            EmployeeDAL objclass = new EmployeeDAL();
            return objclass.AddEmployee(objbo);
        }
        public int EditEmployee(EmployeeBO objbo)
        {
            EmployeeDAL objclass = new EmployeeDAL();
            return objclass.EditEmployee(objbo);
        }

    }
}
