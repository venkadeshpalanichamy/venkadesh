﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using DAL;

namespace BLL
{
    public class SROBLL
    {
         public int EditSRO(SROBO objbo)
        {
            SRODAL objclass = new SRODAL();
            return objclass.EditSRO(objbo);
        }

        public int addsro(SROBO bo)
        {
            SRODAL dalobj = new SRODAL();
            return dalobj.create(bo);
        }

    }
}
