﻿using BO;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class EmployeeDAL
    {
        public int AddEmployee(EmployeeBO objemp)
        {
            try { 
            SqlConnection conn = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;Integrated Security=False;User ID=mms73group4;Password=mms73group4;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

            int ret = 0;
            int returnedID;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("usp_addEmployee", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@FirstName", objemp.FirstName));
                cmd.Parameters.Add(new SqlParameter("@LastName", objemp.LastName));
                cmd.Parameters.Add(new SqlParameter("@DateOfBirth", objemp.Dob));
                cmd.Parameters.Add(new SqlParameter("@Gender", objemp.Gender));
                cmd.Parameters.Add(new SqlParameter("@Email", objemp.Email));
                cmd.Parameters.Add(new SqlParameter("@Address", objemp.Address));
                cmd.Parameters.Add(new SqlParameter("@ContactNo", objemp.Contactno));
                cmd.Parameters.Add(new SqlParameter("@YearsofExperience", objemp.Yoe));
                cmd.Parameters.Add(new SqlParameter("@DateOfJoining", objemp.Doj));
                cmd.Parameters.Add(new SqlParameter("@CTC", objemp.Ctc));
                cmd.Parameters.Add(new SqlParameter("@Password", objemp.Password));
                cmd.Parameters.Add(new SqlParameter("@Role", objemp.Role));
                cmd.Parameters.Add(new SqlParameter("@Place", objemp.Place));
                cmd.Parameters.Add(new SqlParameter("@Status", objemp.Status));

                cmd.Parameters.Add(new SqlParameter("@EmployeeID", SqlDbType.Int));
                cmd.Parameters["@EmployeeID"].Direction = ParameterDirection.Output;
                ret = cmd.ExecuteNonQuery();

                returnedID = Convert.ToInt32(cmd.Parameters["@EmployeeID"].Value);
                conn.Close();
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }

            if (ret == 1)
            {
                return returnedID;
            }
            else
                return 0;
            }
            catch (Exception ex)
            {
                return 0;
            }

        }

        public int EditEmployee(EmployeeBO objbo)
        {
            try
            {
                SqlConnection conn = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;Integrated Security=False;User ID=mms73group4;Password=mms73group4;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");

                int ret = 0;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd = new SqlCommand("usp_editEmployee", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@id", objbo.Id));
                cmd.Parameters.Add(new SqlParameter("@fn", objbo.FirstName));
                cmd.Parameters.Add(new SqlParameter("@ln", objbo.LastName));
                cmd.Parameters.Add(new SqlParameter("@dob", objbo.Dob));
                cmd.Parameters.Add(new SqlParameter("@gender", objbo.Gender));
                cmd.Parameters.Add(new SqlParameter("@email", objbo.Email));
                cmd.Parameters.Add(new SqlParameter("@addrs", objbo.Address));
                cmd.Parameters.Add(new SqlParameter("@cn", objbo.Contactno));
                cmd.Parameters.Add(new SqlParameter("@yoe", objbo.Yoe));
                cmd.Parameters.Add(new SqlParameter("@doj", objbo.Doj));
                cmd.Parameters.Add(new SqlParameter("@ctc", objbo.Ctc));
                cmd.Parameters.Add(new SqlParameter("@pass", objbo.Password));
                cmd.Parameters.Add(new SqlParameter("@role", objbo.Role));
                cmd.Parameters.Add(new SqlParameter("@place", objbo.Place));
                cmd.Parameters.Add(new SqlParameter("@status", objbo.Status));
                ret = cmd.ExecuteNonQuery();
                return ret;

            }
            catch (Exception ex)
            {
                return 0;

            }

        }
}
}
