﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using associatebo;
using System.Data.SqlClient;
using System.Data;
namespace associatedal
{
    public class dal
    {
        //static SqlConnection cn;
        //static SqlCommand cmd;
        public DataTable viewdal(bo objbo)
        {
           SqlConnection cn=new SqlConnection("Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4");
            //cn = new SqlConnection(conStr);
            cn.Open();
            int srid = objbo.sroid;
            string str = "SELECT Createdby,Createddate,Modifiedby,Modifieddate from addsrooffice where SROID="+srid;
            SqlDataAdapter da = new SqlDataAdapter(str, cn);
            DataSet ds = new DataSet();
            da.Fill(ds, "addsrooffice");
            return ds.Tables["addsrooffice"];
            //cmd.CommandType = CommandType.StoredProcedure;
            //cmd.CommandText = "usp_viewassociate";
            //cmd.Parameters.AddWithValue("@sroid", objbo.sroid);
            //SqlDataReader stdReader = cmd.ExecuteReader();

            //if (stdReader.Read())
            //{
            //    objbo.createdby = stdReader["Createdby"].ToString(); //empReader["Name"].ToString() or empReader.GetValue(1).ToString();
            //    objbo.createddate = DateTime.Parse(stdReader["Createddate"].ToString());
            //    objbo.modifiedby = stdReader["Modifiedby"].ToString();
            //    objbo.modifieddate =DateTime.Parse(stdReader["Modifieddate"].ToString());
               

            //}
           

    }
        public DataTable viewall()
        {
            SqlConnection cn = new SqlConnection("Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4");
            //cn = new SqlConnection(conStr);
            cn.Open();
            SqlCommand cmd = new SqlCommand();
            

            SqlDataAdapter da = new SqlDataAdapter("viewall",cn);
            DataSet ds = new DataSet();
            da.Fill(ds,"Employee_Association");

            return ds.Tables["Employee_Association"];
        }
        public DataTable viewbyass(int associateid)
        {
            SqlConnection cn = new SqlConnection("Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4");
            //cn = new SqlConnection(conStr);
        
            SqlCommand cmd = new SqlCommand("viewbypass", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Connection = cn;
            cmd.Parameters.AddWithValue("@associateid", associateid);
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds, "viewbypass");
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
           
            da.Update(ds, "viewbypass");
            
          
       
            return ds.Tables["viewbypass"];
        }
        public void edit(bo objbo)
        {
            SqlConnection cn = new SqlConnection("Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4");
            //cn = new SqlConnection(conStr);
            //cn.Open();
            SqlCommand cmd = new SqlCommand("edit",cn);
            cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Connection = cn;

            SqlDataAdapter da = new SqlDataAdapter();
            cmd.Parameters.AddWithValue("@associateid", objbo.associateid);
            cmd.Parameters.AddWithValue("@sroid", objbo.sroid);
            cmd.Parameters.AddWithValue("@modifiedby", objbo.modifiedby);
            cmd.Parameters.AddWithValue("@modifieddate", objbo.modifieddate);
            //int a = cmd.ExecuteNonQuery();
            //cn.Close();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds, "edit");
           

        }
    }
}
