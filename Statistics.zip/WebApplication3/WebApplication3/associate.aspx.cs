﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using associatebll;
using associatebo;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication3
{
    public partial class associate : System.Web.UI.Page
    {

        static SqlCommand cmd;
        bo boobj = new bo();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //protected void Btn_submit_Click(object sender, EventArgs e)
        //{

        //    boobj.employeeid = int.Parse(txtempid.Value);
        //    boobj.sroid = int.Parse(DropDownList1.SelectedItem.Value);
        //    boobj.description = txtdescription.Value;
        //    bll assbll = new bll();
        //    GridView1.DataSource = assbll.view(boobj);
        //    GridView1.DataBind();

        //    //GridView1.DataSource = assbll.view(boobj);
        //    //GridView1.DataBind();
        //}

        protected void btngetdata_Click(object sender, EventArgs e)
        {
            
                SqlConnection cn = new SqlConnection("Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4");
                cn.Open();
                int empid = int.Parse(txtempid.Value);
                
                int srid = int.Parse(DropDownList1.SelectedItem.Value);
                string Description = txtdescription.Value;
                string conStr = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4";
                cn = new SqlConnection(conStr);
                cn.Open();
                cmd = new SqlCommand("view", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                string createdby = "admin";
                DateTime createddate = DateTime.Now;
                cmd.Parameters.AddWithValue("@employeeid", empid);
                cmd.Parameters.AddWithValue("@sroid", srid);
                cmd.Parameters.AddWithValue("@Description", Description);
                cmd.Parameters.AddWithValue("@createdby", createdby);
                cmd.Parameters.AddWithValue("@createddate", createddate);
                SqlParameter SROid = cmd.Parameters.Add("@associateid", SqlDbType.Int);
                SROid.Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                int assid = (int)cmd.Parameters["@associateid"].Value;
                ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + assid + " assID added');", true);

           
            
            }


        protected void viewall_Click(object sender, EventArgs e)
        {
            bll objbll = new bll();
            DataTable dt = new DataTable();
            GridView2.DataSource = objbll.viewall();
            GridView2.DataBind();
        }

        protected void Btn_edit_Click(object sender, EventArgs e)
        {
            Response.Redirect("editassociate.aspx");
        }
    }

}