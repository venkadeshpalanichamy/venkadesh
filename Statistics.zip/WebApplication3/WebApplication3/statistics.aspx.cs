﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class statistics : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btncount_Click(object sender, EventArgs e)
        {
            int recievedCount = 0;
            int sroid = int.Parse(drpsroid.SelectedItem.Value);
            try
            {
                SqlConnection cn = new SqlConnection("Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4");

                //cn = new SqlConnection(conStr);
                cn.Open();
                SqlCommand cmd = new SqlCommand("countsro", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Connection = cn;
                cmd.Parameters.AddWithValue("@sroid", sroid);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    recievedCount = int.Parse(dr[0].ToString());
                }
                dr.Close();
            }
            catch(Exception ex)
            {

            }
            finally
            {
                
            }
            txtcountsrid.Text = recievedCount.ToString();
           
        }
        protected void btnnotmap_Click(object sender, EventArgs e)
        {
            int recievedCount = 0;
            try
            {
                SqlConnection cn = new SqlConnection("Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4");

                //cn = new SqlConnection(conStr);
                cn.Open();
                SqlCommand cmd = new SqlCommand("countnotmapemp", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Connection = cn;
                //cmd.Parameters.AddWithValue("@sroid", sroid);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    recievedCount = int.Parse(dr[0].ToString());
                }
                dr.Close();
            }
            catch (Exception ex)
            {

            }
            finally
            {

            }
            txtnotmap.Text = recievedCount.ToString();

        }
        protected void btnnotdesig_Click(object sender, EventArgs e)
        {
            int recievedCount = 0;
            try
            {
                SqlConnection cn = new SqlConnection("Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group4;User ID=mms73group4;Password=mms73group4");

                //cn = new SqlConnection(conStr);
                cn.Open();
                SqlCommand cmd = new SqlCommand("countempdetail", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Connection = cn;
                //cmd.Parameters.AddWithValue("@sroid", sroid);

                SqlDataReader dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    recievedCount = int.Parse(dr[0].ToString());
                }
                dr.Close();
            }
            catch (Exception ex)
            {

            }
            finally
            {

            }
            txtempdetail.Text = recievedCount.ToString();

        }
    }
}