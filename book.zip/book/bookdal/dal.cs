﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace bookdal
{
    public class dal
    {
        public int add( string bookname, string author, int price, string category)
        {
            string constr = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;User name=mms73user;Password=mms73user";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand com = new SqlCommand();
            com.CommandType = CommandType.StoredProcedure;
            com.CommandText = "sp_addbook_1203784";
            com.Connection = con;
            
            com.Parameters.AddWithValue("@bookname", bookname);
            com.Parameters.AddWithValue("@author", author);
            com.Parameters.AddWithValue("@price", price);
            com.Parameters.AddWithValue("@category", category);
            int i = com.ExecuteNonQuery();
            return i;

        }
        public DataSet view(string cat)
        {
            string constr = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;User name=mms73user;Password=mms73user";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand com = new SqlCommand();
            com.CommandType = CommandType.StoredProcedure;
            com.CommandText = "sp_viewbook_1203784";
            com.Connection = con;
            com.Parameters.AddWithValue("@category", cat);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;

        }
        public DataSet update(string bookname,string author,int price,int bookid)
        {
            string constr = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;User name=mms73user;Password=mms73user";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand com = new SqlCommand();
            com.CommandType = CommandType.StoredProcedure;
            com.CommandText = "sp_updatebook_1203784";
            com.Connection = con;
            com.Parameters.AddWithValue("@bookname", bookname);
            com.Parameters.AddWithValue("@author", author);
            com.Parameters.AddWithValue("@price", price);
            com.Parameters.AddWithValue("@bookid", bookid);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            return ds;

        }
    }
}
