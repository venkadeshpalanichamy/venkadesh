﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using bookbo;
using bookdal;
using bookbll;

namespace bookui
{
    public partial class bookadd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_add_Click(object sender, EventArgs e)
        {
            userlabel.Text= "welcome" + Session["userid"].ToString();
            lb_user.Text= Session["userid"].ToString();
            
            string bname = txt_bookname.Text;
            string baut = txt_author.Text;
            int bprice = int.Parse(txt_price.Text);
            string bcat= Session["category"].ToString();
            bll objbl = new bll();
            int s = objbl.adddetails(bname, baut, bprice, bcat);
            if (s > 0)
            {
                Response.Write("Inserted Successfully");
            }
            else
            {
                Response.Write("unable to Insert");
            }

        }
    }
}