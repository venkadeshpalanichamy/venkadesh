﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using bookbo;
using bookdal;
using bookbll;

namespace bookui
{
    public partial class viewbookdetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_view_Click(object sender, EventArgs e)
        {
            Label1.Text = "welcome" + Session["userid"].ToString();
            string cat =txt_userid.Text;
            bll objbl = new bll();
            GridView1.DataSource = objbl.viewdetails(cat);
            GridView1.DataBind();
        }

        protected void libtn_Click(object sender, EventArgs e)
        {
            
            Response.Redirect("updatebookdetails.aspx");
        }
    }
}