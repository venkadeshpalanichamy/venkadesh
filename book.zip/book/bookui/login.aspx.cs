﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace bookui
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            if (FormsAuthentication.Authenticate(txt_user.Text, txt_pass.Text))
            {
                FormsAuthentication.RedirectFromLoginPage(txt_user.Text, true);
                Session["userid"] = txt_user.Text;
                Response.Redirect("homepage.aspx");
            }
            else
            {
                Label1.Text = "Invalid user";
            }
            

        }
    }
}