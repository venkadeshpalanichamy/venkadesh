﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using bookbo;
using bookdal;
using bookbll;

namespace bookui
{
    public partial class updatebookdetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btn_update_Click(object sender, EventArgs e)
        {

            userlb.Text = "welcome" + Session["userid"].ToString();
            string name = bname.Text;
            string auth = aut.Text;
            int id =int.Parse(txt_id.Text);
            int pr = int.Parse(price.Text);
            bll objbl = new bll();
            
            GridView1.DataSource = objbl.updatedetails(name, auth, pr,id);
            GridView1.DataBind();

        }
        protected void libtn_Click(object sender, EventArgs e)
        {
            Response.Redirect("updatebookdetails.aspx");
        }

    }
}