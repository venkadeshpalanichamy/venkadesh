﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using bookbo;
using bookdal;

namespace bookbll
{
    public class bll
    {
        public int adddetails(string bookname,string author,int price,string category)
        {
            bo objbo = new bo();
            dal objdal = new dal();
            return objdal.add( bookname, author, price, category);
        }
        public DataSet viewdetails(string category)
        {
            bo objbo = new bo();
            dal objdal = new dal();
            return objdal.view(category);
        }
        public DataSet updatedetails(string bookname,string author,int price,int bookid)
        {
            bo objbo = new bo();
            dal objdal = new dal();
            return objdal.update(bookname,author,price,bookid);
        }
    }
}
