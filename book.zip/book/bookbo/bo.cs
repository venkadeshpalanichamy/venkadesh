﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bookbo
{
    public class bo
    {
        
            int _bookid;
            string _bookname;
            string _author;
            int _price;
            string _category;

            public int Bookid
            {
                get
                {
                    return _bookid;
                }

                set
                {
                    _bookid = value;
                }
            }

            public string Bookname
            {
                get
                {
                    return _bookname;
                }

                set
                {
                    _bookname = value;
                }
            }

            public string Author
            {
                get
                {
                    return _author;
                }

                set
                {
                    _author = value;
                }
            }

            public int Price
            {
                get
                {
                    return _price;
                }

                set
                {
                    _price = value;
                }
            }

            public string Category
            {
                get
                {
                    return _category;
                }

                set
                {
                    _category = value;
                }
            }
            public bo(int bookid, string bookname, string author, int price, string category)
            {
                _bookid = bookid;
                _bookname = bookname;
                _author = author;
                _price = price;
                _category = category;
            }
            public bo()
            { }
        }
    }

