﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OMRSBO;

namespace OMRSBO
{
    public class SRAssistantBO
    {
         int employeeID;
        string name;
        string designation;
        string emailId;
        string address;
        int contactNo;
        string createdBy;
        DateTime createdDate;
        string modifiedBy;
        DateTime modifiedDate;
        Boolean status;
        public int EmployeeID
        {
            get
            {
                return employeeID;
            }
            set
            {
                employeeID = value;

            }
        }
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;

            }
        }

        public string Designation
        {
            get
            {
                return designation;
            }
            set
            {
                designation = value;

            }
        }

             public string EmailId
             {
                 get
                 {
                     return emailId;
                 }
                 set
                 {
                     emailId = value;

                 }
             }
          public string Address
        {
            get
            {
                return address;
            }
            set
            {
                address = value;

            }

        }
          public int ContactNo
          {
              get
              {
                  return contactNo;
              }
              set
              {
                  contactNo = value;

              }
          }
          public string CreatedBy
          {
              get
              {
                  return createdBy;
              }
              set
              {
                  createdBy = value;

              }

          }
          public DateTime CreatedDate
          {
              get
              {
                  return createdDate;

              }
              set
              {
                  createdDate = value;
              }

          }
          public string ModifiedBy
          {
              get
              {
                  return modifiedBy;
              }
              set
              {
                  modifiedBy = value;

              }

          }
          public DateTime ModifiedDate
          {
              get
              {
                  return modifiedDate;

              }
              set
              {
                  modifiedDate = value;
              }
          }
        public Boolean Status
          {
            get
              {
                  return status;
                
              }
            set
              {
                  status = value;
              }
          }



          public SRAssistantBO()
          {
          }

                       
                      
    }
}
