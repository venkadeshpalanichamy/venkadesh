﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using OMRSBO;
using OMRSBLL;

namespace OMRSUI
{
    public partial class SRAssistant : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btncreate_Click(object sender, EventArgs e)
        {
            SRAssistantBO objassistant = new SRAssistantBO();
            objassistant.EmployeeID =int.Parse(txtemployeeID.Text);
            objassistant.Name=txtname.Text;
            objassistant.Designation=txtdesignation.Text;
            objassistant.EmailId=txtemailid.Text;
            objassistant.Address=txtaddress.Text;
            objassistant.ContactNo=int.Parse(txtcontactno.Text);
            objassistant.CreatedBy=txtcreatedby.Text;
            objassistant.CreatedDate = DateTime.Parse(txtcreatedate.Text);
            objassistant.ModifiedBy = txtmodifiedby.Text;
            objassistant.ModifiedDate = DateTime.Parse(txtmodifieddate.Text);


            SRAsssistantBLL objassistantbll = new SRAsssistantBLL();

            int ret=objassistantbll.addSRAssistant(objassistant);
            
            
            
                    
        }
    }
}