namespace WebApplication5.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("product")]
    public partial class product
    {
        public int productId { get; set; }

        [Required]
        [StringLength(50)]
        public string name { get; set; }

        [StringLength(100)]
        public string colors { get; set; }

        [StringLength(200)]
        public string description { get; set; }

        [Column(TypeName = "money")]
        public decimal? price { get; set; }

        public int? categoryId { get; set; }

        public int? isActive { get; set; }
    }

}
