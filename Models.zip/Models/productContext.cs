﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;


namespace WebApplication5.Models 
{
    public class productContext : DbContext
    {
        public DbSet<product> product { get; set; }

    }
}