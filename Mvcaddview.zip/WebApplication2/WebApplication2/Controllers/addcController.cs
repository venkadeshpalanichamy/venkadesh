﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication2.Models;
using BO;
using BLL;

namespace WebApplication2.Controllers
{
    public class addcController : Controller
    {
        // GET: addc
        public ActionResult Index()
        {
            return View();
        }

        // GET: addc/Details/5
        public ActionResult Details()
        {
            addBLL objaddBLL = new addBLL();
            List<addBO> lstaddBO = objaddBLL.ViewAllbll();
            lstaddBO.Reverse();

            List<add> lstaddModel = new List<add>();
            foreach (addBO objaddBO in lstaddBO)
            {
                add objaddModel = new add();
                objaddModel.a= objaddBO.a;
                objaddModel.b = objaddBO.b;
                objaddModel.total = objaddBO.total;

                lstaddModel.Add(objaddModel);
            }
            return View();
        }

        // GET: addc/Create
        public ActionResult Create()
        {
            add objaddModel = new add();
            //objEmployeeViewModel.CountryList = GetAllCountries();

            return View("create", objaddModel);

            return View();
        }

        // POST: addc/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            //try
            //{

                if (ModelState.IsValid)
                {
                    addBO objaddBO = new addBO();
                    objaddBO.a = int.Parse(Request.Form["a"]);
                    objaddBO.b = int.Parse(Request.Form["b"]);
                    objaddBO.total = int.Parse(Request.Form["total"]);

                    add objaddModel = new add();


                    addBLL objEmployeeBLL = new addBLL();
                    int a = objEmployeeBLL.addbll(objaddBO);
                    ViewBag.Message = String.Format("Success: Employee added. Employee Id is {0}", a);
                }
                return View("Details");
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            //}
            //catch
            //{
            //    return View();
            //}
        }

        // GET: addc/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: addc/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: addc/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: addc/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
