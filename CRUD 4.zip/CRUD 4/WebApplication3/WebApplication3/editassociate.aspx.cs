﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using associatebll;
using associatebo;
namespace WebApplication3
{
    public partial class editassociate : System.Web.UI.Page
    {
        associateEmployeeBO objbo = new associateEmployeeBO();
        associateEmployeeBLL objbll = new associateEmployeeBLL();
        //bo objbo = new bo();
        //bll objbll = new bll();
        protected void Page_Load(object sender, EventArgs e)
        {
            txtmodifieddate.Value = DateTime.Now.ToString();
            txtmodifiedby.Value = "admin";
        }

        public void Btn_edit_Click(object sender, EventArgs e)
        {
            int associateid = int.Parse(Dropdownlist1.SelectedItem.Value);
            GridView1.DataSource=objbll.viewbyass(associateid);
            GridView1.DataBind();
           
        }

        protected void btnedit_Click(object sender, EventArgs e)
        {
            objbo.associateid = int.Parse(Dropdownlist1.SelectedItem.Value);
            objbo.sroid = int.Parse(txtsroid.Value);
            objbo.modifieddate=DateTime.Parse(txtmodifieddate.Value);
            
            objbo.modifiedby=txtmodifiedby.Value;
            objbll.edit(objbo);

            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + objbo.associateid+ "'assid edited);", true);


        }
    }
}