﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using associatebll;
using associatebo;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication3
{
    public partial class associate : System.Web.UI.Page
    {

        static SqlCommand cmd;
        associateEmployeeBO objbo = new associateEmployeeBO();
        associateEmployeeBLL objbll = new associateEmployeeBLL();
        //bo objbo = new bo();
        //bll objbll = new bll();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btngetdata_Click(object sender, EventArgs e)
        {
            int i = 0;
            objbo.employeeid = int.Parse(txtempid.Value);
            objbo.sroid = int.Parse(DropDownList1.SelectedItem.Value);
            objbo.Description = txtdescription.Value;
            i = objbll.getdata(objbo);
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('" + i + " assID Created');", true);

        }



        protected void viewall_Click(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            GridView2.DataSource = objbll.viewall();
            GridView2.DataBind();
        }

        protected void Btn_edit_Click(object sender, EventArgs e)
        {
            Response.Redirect("editassociate.aspx");
        }
    }

}