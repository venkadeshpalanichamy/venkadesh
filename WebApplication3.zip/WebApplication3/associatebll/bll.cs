﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using associatedal;
using associatebo;
using System.Data;

namespace associatebll
{
    public class bll
    {
        dal objdal = new dal();
        public DataTable view(bo objbo)
        {
            return objdal.viewdal(objbo);

        }
    }
}
