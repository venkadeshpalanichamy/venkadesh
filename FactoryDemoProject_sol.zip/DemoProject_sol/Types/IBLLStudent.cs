﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Types
{
    public interface IBLLStudent
    {
        int CreateStudent(IBOStudent objstdbo);
        DataSet ViewStudent();
        int UpdateStudent(IBOStudent objstdbo);
        int DeleteStudent(IBOStudent objstdbo);
    }
}
