﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Types;
using studentBLLFactory;
using studentBOFactory;

namespace DemoProject
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label2.Text = "Welcome to   " + Session["name"].ToString();
        }

        protected void Add_Click(object sender, EventArgs e)
        {
            int i;
            IBOStudent objstdbo = studentBOFactory.StudentBOFactory.CreateObjectBO();
            objstdbo.Name = txtstudentname.Text;
            objstdbo.Address = txtstudentaddress.Text;
            objstdbo.Branch = ddlbranch.SelectedValue;
            IBLLStudent objbl = studentBLLFactory.StudentBLLFactory.CreateObjectBLL();
            i = objbl.CreateStudent(objstdbo);
            Label1.Text = "student added and ID is:" + i;
            //if(i==1)
            //{
            //    Page.ClientScript.RegisterStartupScript(this.GetType(), "alertkey", "<script>alert('i''Details Updated successfully');</script>", false);
            //}
        }

        protected void view_Click(object sender, EventArgs e)
        {
            Response.Redirect("Studentview.aspx");
        }
    }
}