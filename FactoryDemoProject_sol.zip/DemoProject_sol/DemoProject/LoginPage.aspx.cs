﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace DemoProject
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void login_Click(object sender, EventArgs e)
        {
            if(FormsAuthentication.Authenticate(txtusername.Text,txtpassword.Text))
            {
                Session["name"] = txtusername.Text;
                FormsAuthentication.RedirectFromLoginPage(txtusername.Text,false);
            }
            else
            {
                Label1.Visible=true;
                Label1.Text="Invalied Credentials";
            }
        }
        
    }
}