﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Types;
using studentBLLFactory;
using studentBOFactory;
using System.Data;

namespace DemoProject
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            bindStudent();
        }
        protected void bindStudent()
        {
            IBLLStudent obj3 = studentBLLFactory.StudentBLLFactory.CreateObjectBLL();
            DataSet dset;
            dset = obj3.ViewStudent();
            grdStudent.DataSource = dset;
            grdStudent.DataBind();
        }
        protected void grdStudent_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grdStudent.EditIndex = e.NewEditIndex;
            bindStudent();

        }

        protected void grdStudent_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

            GridViewRow row = grdStudent.Rows[e.RowIndex];
            HiddenField hdnID = (HiddenField)row.FindControl("hdnID");
            IBOStudent objstdbo = studentBOFactory.StudentBOFactory.CreateObjectBO();
            IBLLStudent obj5 = studentBLLFactory.StudentBLLFactory.CreateObjectBLL();
            objstdbo.Id = Convert.ToInt32(hdnID.Value);
            int result = obj5.DeleteStudent(objstdbo);

            grdStudent.EditIndex = -1;
            bindStudent();
        }
        protected void grdStudent_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int result = 0;

            GridViewRow row = grdStudent.Rows[e.RowIndex];
            HiddenField hdnID = (HiddenField)row.FindControl("hdnID");
            TextBox txtName = (TextBox)row.FindControl("txtName");
            TextBox txtAddress = (TextBox)row.FindControl("txtAddress");
            IBOStudent objstdbo=studentBOFactory.StudentBOFactory.CreateObjectBO();
            IBLLStudent obj4=studentBLLFactory.StudentBLLFactory.CreateObjectBLL();
            objstdbo.Id = Convert.ToInt32(hdnID.Value);
            objstdbo.Name = txtName.Text;
            objstdbo.Address = txtAddress.Text;
            result = obj4.UpdateStudent(objstdbo);
            if (result == 1)
            {
                Page.ClientScript.RegisterStartupScript(this.GetType(), "alertkey", "<script>alert('Details Updated successfully');</script>", false);
            }
            //Move to normal mode
            grdStudent.EditIndex = -1;
            bindStudent();
        }

        protected void grdStudent_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdStudent.EditIndex = -1;
            bindStudent();
        }
    }
}