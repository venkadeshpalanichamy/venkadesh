﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
using studentDALFactory;
using System.Data;

namespace StudentBLL
{
    public class studentBLL:IBLLStudent
    {
        public int CreateStudent(IBOStudent objstdbo)
        {
            int ret = 0;
            IDALStudent dal =studentDALFactory.StudentDALFactory.CreateObjectDAL();
            ret=dal.CreateStudent(objstdbo);
            return ret;
        }
        public DataSet ViewStudent()
        {
            DataSet ds;
            IDALStudent dal1 = studentDALFactory.StudentDALFactory.CreateObjectDAL();
            ds = dal1.ViewStudent();
            return ds;
        }
        public int UpdateStudent(IBOStudent objstdbo)
        {
            int rowAffected = 0;
            IDALStudent dal2 = studentDALFactory.StudentDALFactory.CreateObjectDAL();
            rowAffected=dal2.UpdateStudent(objstdbo);
            return rowAffected;
        }
        public int DeleteStudent(IBOStudent objstdbo)
        {
            int rowAffected = 0;
            IDALStudent dal3 = studentDALFactory.StudentDALFactory.CreateObjectDAL();
            rowAffected=dal3.DeleteStudent(objstdbo);
            return rowAffected;
        }

    }
}
