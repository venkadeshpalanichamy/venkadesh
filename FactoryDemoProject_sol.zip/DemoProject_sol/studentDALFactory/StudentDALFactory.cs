﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
using studentDAL;

namespace studentDALFactory
{
    public class StudentDALFactory
    {
        public static IDALStudent CreateObjectDAL()
        {
            IDALStudent obj=new StudentDAL() ;
            return obj;
        }
    }
}
