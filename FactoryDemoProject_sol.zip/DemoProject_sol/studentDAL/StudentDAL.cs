﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
using studentBOFactory;
using System.Data;
using System.Data.SqlClient;

namespace studentDAL
{
    public class StudentDAL:IDALStudent
    {
        public int CreateStudent(IBOStudent objstdbo) 
        {
            int ret=0;
            string connectionstring = ("Server=INCHNILPDB02\\mssqlserver1;Database=CHN16MMS102Group2;User=CHN16MMS102Group2;Password=CHN16MMS102Group2");
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand("studentadd", connection);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@stdbranch",objstdbo.Branch));
            command.Parameters.Add(new SqlParameter("@stdname",objstdbo.Name));
            command.Parameters.Add(new SqlParameter("@stdaddress", objstdbo.Address));
            command.Parameters.AddWithValue("@stdid", 0);
            command.Parameters["@stdid"].Direction = ParameterDirection.Output;
            connection.Open();
            ret=command.ExecuteNonQuery();
            connection.Close();
            if (ret == 1)
            {
                return (Convert.ToInt32(command.Parameters["@stdid"].Value));
            }
            else
                return 0;
        }
        public DataSet ViewStudent()
        {
            string connectionstring = ("Server=INCHNILPDB02\\mssqlserver1;Database=CHN16MMS102Group2;User=CHN16MMS102Group2;Password=CHN16MMS102Group2");
            SqlConnection connection = new SqlConnection(connectionstring);
            SqlCommand command = new SqlCommand("student_view", connection);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            SqlDataAdapter adapter = new SqlDataAdapter();
            DataSet ds = new DataSet();
            adapter.SelectCommand = command;
            adapter.Fill(ds);
            return ds;
        }
      
        public int UpdateStudent(IBOStudent objstdbo)
        {
            int rowAffected = 0;
            string connectionstring = ("Server=INCHNILPDB02\\mssqlserver1;Database=CHN16MMS102Group2;User=CHN16MMS102Group2;Password=CHN16MMS102Group2");
            SqlConnection connection = new SqlConnection(connectionstring);
            connection.Open();
            SqlCommand command = new SqlCommand("studentupdate", connection);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@stdname", objstdbo.Name));           
            command.Parameters.Add(new SqlParameter("@stdaddress", objstdbo.Address));
            command.Parameters.Add(new SqlParameter("@stdid", objstdbo.Id));
            
           
            rowAffected = command.ExecuteNonQuery();
            connection.Close();
            return rowAffected;
        }
        public int DeleteStudent(IBOStudent objstdbo)
        {
            int rowAffected = 0;
            string connectionstring = ("Server=INCHNILPDB02\\mssqlserver1;Database=CHN16MMS102Group2;User=CHN16MMS102Group2;Password=CHN16MMS102Group2");
            SqlConnection connection = new SqlConnection(connectionstring);
            connection.Open();
            SqlCommand command = new SqlCommand("studentdelete", connection);
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.Parameters.Add(new SqlParameter("@stdid",objstdbo.Id));
            rowAffected = command.ExecuteNonQuery();
            connection.Close();
            return rowAffected;
        }
    }
}
