﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
using StudentBLL;

namespace studentBLLFactory
{
    public class StudentBLLFactory
    {
        public static IBLLStudent CreateObjectBLL()
        {
            IBLLStudent obj = new studentBLL();
            return obj;
        }
    }
}
