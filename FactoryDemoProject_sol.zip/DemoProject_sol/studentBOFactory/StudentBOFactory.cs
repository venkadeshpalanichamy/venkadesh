﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
using StudentBO;

namespace studentBOFactory
{
    public class StudentBOFactory
    {
        public static IBOStudent CreateObjectBO()
        {
            IBOStudent obj = new studentBO();
            return obj;
        }
    }
}
