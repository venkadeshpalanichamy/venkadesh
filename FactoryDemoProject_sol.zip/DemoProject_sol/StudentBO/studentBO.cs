﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;

namespace StudentBO
{
    public class studentBO: IBOStudent
    {
        int stdid;
        string stdname;
        string stdaddress;
        string stdbranch;

        public int Id { get { return stdid;} set { stdid=value;} }
        public string Name { get { return stdname; } set { stdname=value;} }
        public string Address { get{return stdaddress;} set{stdaddress=value;} }
        public string Branch { get { return stdbranch; } set { stdbranch = value; } }
        public studentBO() { }

        public studentBO(int id, string name, string address) {
            stdid = id;
            stdname = name;
            stdaddress = address;
        }
    }
}
