create table cms_tbl_1197372(
courseid int identity(1,1) primary key not null,
coursename varchar(20)not null ,
descriptions Varchar(100) not null,
mode  varchar(20) not null,
category varchar(20) not null,
userid varchar(10) not null)

select * from cms_tbl_1197372

create proc cms_sp_add(@coursename varchar(20),@descriptions Varchar(100),@mode  varchar(20),@category varchar(20),@userid varchar(10))
as
begin
insert into cms_tbl_1197372 values (@coursename,@descriptions,@mode,@category,@userid)
end

exec cms_sp_add 'c','learn','ILT','Technical','priyanka'
exec cms_sp_add 'c++','learn','ILT','Technical','priyanka'
exec cms_sp_add 'c#','learn','ILT','Technical','priyanka'
exec cms_sp_add 'java','learn','ILT','Technical','priyanka'

create proc cms_sp_view
as
begin
select * from cms_tbl_1197372
end
exec cms_sp_view

create proc cms_sp_delete(@courseid int)
as
begin
delete from cms_tbl_1197372 where courseid=@courseid
end
exec cms_sp_delete 1

