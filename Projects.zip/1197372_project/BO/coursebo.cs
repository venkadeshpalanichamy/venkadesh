﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ITYPES;


namespace BO
{
    public class coursebo :icoursebo
    {
        int courseid1;
        string coursename1;
        string descriptions1;
        string mode1;
        string category1;
        string userid1;

        public int courseid
        {
            get
            {
                return courseid1;
            }

            set
            {
                courseid1 = value;
            }
        }

        public string coursename
        {
            get
            {
                return coursename1;
            }

            set
            {
                coursename1 = value;
            }
        }

        public string descriptions
        {
            get
            {
                return descriptions1;
            }

            set
            {
                descriptions1 = value;
            }
        }

        public string mode
        {
            get
            {
                return mode1;
            }

            set
            {
                mode1 = value;
            }
        }

        public string category
        {
            get
            {
                return category1;
            }

            set
            {
                category1 = value;
            }
        }

        public string userid
        {
            get
            {
                return userid1;
            }

            set
            {
                userid1 = value;
            }
        }
    }
}
