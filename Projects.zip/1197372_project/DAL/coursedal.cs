﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using BO;
using ITYPES;

namespace DAL
{
    public class coursedal : icoursedal
    {
        string str = "Data Source = inchnilpdb02\\mssqlserver1;Initial Catalog = CHN12_MMS73_TEST; User ID = mms73user; Password=mms73user";
        public int adddal(icoursebo obj)
        {
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand com = new SqlCommand("cms_sp_add", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@coursename", obj.coursename);
            com.Parameters.AddWithValue("@descriptions", obj.descriptions);
            com.Parameters.AddWithValue("@mode", obj.mode);
            com.Parameters.AddWithValue("@category", obj.category);
            com.Parameters.AddWithValue("@userid", obj.userid);
            int i = com.ExecuteNonQuery();
            con.Close();
            return i;
        }
        public DataTable viewdal()
        {
            SqlConnection con = new SqlConnection(str);           
            SqlCommand com = new SqlCommand("cms_sp_view", con);
            com.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = com;
            DataSet ds = new DataSet();
            da.Fill(ds, "cms_sp_view");
            return ds.Tables["cms_sp_view"];
        }
        public int deletedal(icoursebo obj)
        {
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand com = new SqlCommand("cms_sp_delete", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@courseid", obj.courseid);
            int i = com.ExecuteNonQuery();
            con.Close();
            return i;
        }
    }
}
