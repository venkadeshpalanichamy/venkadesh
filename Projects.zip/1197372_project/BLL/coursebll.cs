﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using BO;
using DAL;
using ITYPES;

namespace BLL
{
    public class coursebll : icoursebll
    {
        public int add(icoursebo obj)
        {
            coursedal objdal = new coursedal();
            return objdal.adddal(obj);
        }
        public DataTable view()
        {
            coursedal objdal = new coursedal();
            return objdal.viewdal();
        }
        public int delete(icoursebo obj)
        {
            coursedal objdal = new coursedal();
            return objdal.deletedal(obj);
        }
    }
}
