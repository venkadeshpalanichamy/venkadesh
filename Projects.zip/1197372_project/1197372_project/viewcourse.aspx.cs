﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BLL;
using ITYPES;

namespace _1197372_project
{
    public partial class viewcourse : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["userid"] != null)
            {
                Label1.Text = Session["userid"].ToString();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            icoursebll objbll = new coursebll();
            GridView1.DataSource = objbll.view();
            GridView1.DataBind();
        }
    }
}