﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;
using ITYPES;

namespace _1197372_project
{
    public partial class deletecourse : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["userid"] != null)
            {
                Label1.Text = Session["userid"].ToString();
            }
            icoursebll objbll = new coursebll();
            GridView1.DataSource = objbll.view();
            GridView1.DataBind();
           
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            var id = (Control)sender;
            GridViewRow row = (GridViewRow)id.NamingContainer;
            string courseid1 = row.Cells[0].Text;
            int courseid = int.Parse(courseid1);
            icoursebo obj = new coursebo();
            obj.courseid = courseid;
            icoursebll objbll = new coursebll();
            int i = objbll.delete(obj);
            if(i>0)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "showmsg", "alert(' Successfully deleted')", true);
            }

        }

        protected void btn_verify_Click(object sender, EventArgs e)
        {
            GridView1.Visible = false;
            icoursebll objbll = new coursebll();
            GridView2.DataSource = objbll.view();
            GridView2.DataBind();
        }
    }
}