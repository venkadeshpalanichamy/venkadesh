﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;
using ITYPES;

namespace _1197372_project
{
    public partial class addcourse : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["category"]!=null)
            {
                txt_cate.Text = Session["category"].ToString();
            }
            if (Session["userid"] != null)
            {
                Label1.Text = Session["userid"].ToString();
            }

        }

        protected void byn_sub_add_Click(object sender, EventArgs e)
        {
            string coursename = txt_name.Text;
            string userid = Label1.Text;
            string descriptions = txt_desc.Text;
            string mode = DropDownList1.SelectedItem.ToString();
            string category = Session["category"].ToString();
            icoursebo objbo = new coursebo();
            objbo.coursename = coursename;
            objbo.userid = userid;
            objbo.descriptions = descriptions;
            objbo.mode = mode;
            objbo.category = category;
            icoursebll objbll = new coursebll();
            int i = objbll.add(objbo);
            if(i>0)
            {
                ClientScript.RegisterStartupScript(this.GetType(), "showmsg", "alert('Successfully added ')", true);

            }

        }
    }
}