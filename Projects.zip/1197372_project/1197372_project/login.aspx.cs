﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace _1197372_project
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            

        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            if (FormsAuthentication.Authenticate(txt_id.Text, txt_pwd.Text))
            {
                Session["userid"] = txt_id.Text;
                Response.Redirect("home.aspx");
                Response.Redirect("addcourse.aspx");
                Response.Redirect("viewcourse.aspx");
                Response.Redirect("deletecourse.aspx");
            }
        }
    }
}