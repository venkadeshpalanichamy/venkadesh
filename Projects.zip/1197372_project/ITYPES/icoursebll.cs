﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ITYPES
{
    public interface icoursebll
    {
        int add(icoursebo obj);
        int delete(icoursebo obj);
        DataTable view();
    }
}
