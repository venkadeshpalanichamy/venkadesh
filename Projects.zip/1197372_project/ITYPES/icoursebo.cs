﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ITYPES
{
    public interface icoursebo 
    {
        string category { get; set; }
        int courseid { get; set; }
        string coursename { get; set; }
        string descriptions { get; set; }
        string mode { get; set; }
        string userid { get; set; }
    }
}
